class Narrator:
    def retell(self, dream_text: str):
        return f"In the hush between night and day, your dream unfolded: {dream_text}. Its echoes invite reflection and story."
